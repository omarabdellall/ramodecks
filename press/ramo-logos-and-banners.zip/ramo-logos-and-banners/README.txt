RAMO wordmark: -white is for dark backgrounds, -black for light, -orange for dark flyers.
Banners: 16:9 for LED screens (1920x1080 and 3840x2160). Square 1080 and story 1080x1920 for flyers and socials.
Do not stretch, recolor or add effects to the wordmark.
